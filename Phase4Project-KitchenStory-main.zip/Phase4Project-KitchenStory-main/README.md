# Phase4Project-KitchenStory
App Name - KitchenStory.com V1.0.1\
Buying food items made smooth. Use the app to burn your hunger. Add items, remove items and much more !!\
Developer Name: Aakash Patel\
Email: Aksh.2102@gmail.com

## Available Scripts

### `npm install`

Run this script in both, the root folder and the ExpressBackend folder to install all the dependencies.

### `npm start`

After extracting the project, you first need to start the express backend server.<br />
In the 'kitchen_story' folder, navigate to the 'ExpressBackend' folder. Open the terminal here and then run 'npm start'.<br />
This will start the backend server at [http://localhost:3001](http://localhost:3001)

Now, to start the frontend react server, navigate to the root folder 'kitchen_storyU', open the terminal there and then run 'npm start' command.<br />
This will start the frontend server at [http://localhost:3000](http://localhost:3000)
